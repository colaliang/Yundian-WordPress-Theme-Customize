<?php
/**
 * Footer Contact Component
 *
 * @package ERDU_Lighting
 */

if (!defined('ABSPATH')) {
    exit;
}

class Erdu_Footer_Contact {
    public static function render($settings, $theme_settings) {
        $address = $theme_settings['address'] ?? '';
        $phone = $theme_settings['phone'] ?? '';
        $email = $theme_settings['email'] ?? '';
        $hours = $theme_settings['hours'] ?? '';
        $whatsapp = $theme_settings['whatsapp'] ?? '';
        $wechat = $theme_settings['wechat'] ?? '';

        if (!$settings['contact_show'] || (!$address && !$phone && !$email && !$hours && !$whatsapp && !$wechat)) {
            return;
        }
        ?>
        <div>
            <h4 class="font-semibold mb-4" style="color: <?php echo esc_attr($settings['heading_color']); ?>;"><?php echo esc_html($settings['contact_title']); ?></h4>
            <ul class="space-y-3 text-sm">
                <?php if ($address) : ?>
                <li class="flex items-start gap-2">
                    <svg class="w-4 h-4 mt-0.5 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span><?php echo nl2br(esc_html($address)); ?></span>
                </li>
                <?php endif; ?>
                
                <?php if ($phone) : ?>
                <li class="flex items-center gap-2">
                    <svg class="w-4 h-4 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    <span><?php echo esc_html($phone); ?></span>
                </li>
                <?php endif; ?>
                
                <?php if ($email) : ?>
                <li class="flex items-center gap-2">
                    <svg class="w-4 h-4 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    <a href="mailto:<?php echo esc_attr($email); ?>" class="transition-colors hover:underline" onmouseover="this.style.color='<?php echo esc_attr($settings['hover_color']); ?>'" onmouseout="this.style.color=''"><?php echo esc_html($email); ?></a>
                </li>
                <?php endif; ?>

                <?php if ($whatsapp) : ?>
                <li class="flex items-center gap-2">
                    <svg class="w-4 h-4 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    <a href="<?php echo esc_url($whatsapp); ?>" target="_blank" class="transition-colors hover:underline" onmouseover="this.style.color='<?php echo esc_attr($settings['hover_color']); ?>'" onmouseout="this.style.color=''"><?php _e('WhatsApp', 'erdu-wp'); ?></a>
                </li>
                <?php endif; ?>

                <?php if ($wechat) : ?>
                <li class="flex items-center gap-2 group relative">
                    <svg class="w-4 h-4 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="currentColor" viewBox="0 0 24 24"><path d="M16.59 13.56c2.95 0 5.36-1.95 5.36-4.36 0-2.4-2.4-4.36-5.36-4.36-2.95 0-5.36 1.95-5.36 4.36 0 2.4 2.4 4.36 5.36 4.36zm-1.84-5.3c.3 0 .54.24.54.54s-.24.54-.54.54-.54-.24-.54-.54.24-.54.54-.54zm3.68 0c.3 0 .54.24.54.54s-.24.54-.54.54-.54-.24-.54-.54.24-.54.54-.54zm-11.08 7.3c-3.9 0-7.05-2.6-7.05-5.8 0-3.2 3.15-5.8 7.05-5.8 3.9 0 7.05 2.6 7.05 5.8 0 3.2-3.15 5.8-7.05 5.8zm-2.42-7.04c.4 0 .72.32.72.72s-.32.72-.72.72-.72-.32-.72-.72.32-.72.72-.72zm4.84 0c.4 0 .72.32.72.72s-.32.72-.72.72-.72-.32-.72-.72.32-.72.72-.72z"/></svg>
                    <span><?php echo esc_html($wechat); ?></span>
                </li>
                <?php endif; ?>
                
                <?php if ($hours) : ?>
                <li class="flex items-center gap-2">
                    <svg class="w-4 h-4 shrink-0" style="color: <?php echo esc_attr($settings['hover_color']); ?>;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span><?php echo esc_html($hours); ?></span>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <?php
    }
}